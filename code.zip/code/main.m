clear;clc;close all;
%% Choose Data and set parameters
row=256;col=324;%% ASL Sempach 5
count=120;% Total frames of the video
cd(fileparts(mfilename('fullpath')));

lpfCoeff = wfilters('db1','l');% haar(db1) or sym8   
K=1;%Set K to 1-100, default:1
maxiterS=50;
S=zeros(row,col);
SumI=zeros(row,col);
old_ES=0;

for i=1:count% Use count for video or maxiterS for single frame
    pause(0.0001);
    %% Read image "Raw"
    file_name = fullfile('Sempach5', [num2str(i) '.png']); 
    Raw=double(imread(file_name));% "Raw" denotes the image after calibration pre-correction
    %% Algorithm 1 for single image(Choose one from  Algorithm 1 and 2 )
    % [S,ES] = Destripe(Raw,S,lpfCoeff,K);
    % if abs(ES-old_ES)<1e-5;     break;    end;    old_ES=ES;
    %% Algorithm 2 for video (Choose one from  Algorithm 1 and 2 )
    SumI=(Raw+(i-1)*SumI)/i;
    [S,~] = Destripe(SumI,S,lpfCoeff,K);
    %% Show
    I_new=Raw+S;% Corrected image
    show1=HistogramEqualization(Raw,10);
    show2=HistogramEqualization(I_new,10);
    imshow([show1,show2],[],'Border','loose');title(i);
end
fclose all;