%% Energy of 1D gradient (EHG1D) 

function out=EHG1D(I) 
    I=mean(I); % Compute horizontal gradient energy for vertical rank-1 stripes
    % I=mean(I,2); % Compute vertical gradient energy for vertical rank-1 stripes
    
    B=diff(I,1);
    B2=B.*B;
    out=sum((B2(:)))/length(I);
end